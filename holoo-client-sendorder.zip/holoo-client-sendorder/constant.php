<?php

define('BASE_URL_PLUGIN_SENDORDER', "http://2.187.99.27:5000/api/");
